module github.com/example/notehub

go 1.23.0

require (
	github.com/google/uuid v1.6.0
	gorm.io/driver/postgres v1.6.0
	gorm.io/driver/sqlite v1.6.0
	gorm.io/gorm v1.31.2
)
