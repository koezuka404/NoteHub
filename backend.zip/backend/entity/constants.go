package entity

type UserStatus string

const (
	UserStatusActive    UserStatus = "active"
	UserStatusSuspended UserStatus = "suspended"
	UserStatusDeleted   UserStatus = "deleted"
)

func (s UserStatus) IsValid() bool {
	return s == UserStatusActive || s == UserStatusSuspended || s == UserStatusDeleted
}

type WorkspaceRole string

const (
	WorkspaceRoleHost   WorkspaceRole = "host"
	WorkspaceRoleEditor WorkspaceRole = "editor"
	WorkspaceRoleViewer WorkspaceRole = "viewer"
)

func (r WorkspaceRole) IsValid() bool {
	return r == WorkspaceRoleHost || r == WorkspaceRoleEditor || r == WorkspaceRoleViewer
}

type DocumentVersionType string

const (
	DocumentVersionManual   DocumentVersionType = "manual"
	DocumentVersionAutosave DocumentVersionType = "autosave"
	DocumentVersionRestore  DocumentVersionType = "restore"
)

func (t DocumentVersionType) IsValid() bool {
	return t == DocumentVersionManual || t == DocumentVersionAutosave || t == DocumentVersionRestore
}

type RefreshTokenStatus string

const (
	RefreshTokenStatusActive  RefreshTokenStatus = "active"
	RefreshTokenStatusUsed    RefreshTokenStatus = "used"
	RefreshTokenStatusRevoked RefreshTokenStatus = "revoked"
)

func (s RefreshTokenStatus) IsValid() bool {
	return s == RefreshTokenStatusActive || s == RefreshTokenStatusUsed || s == RefreshTokenStatusRevoked
}
