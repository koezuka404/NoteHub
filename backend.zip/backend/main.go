package main

import (
	"context"
	"log"
	"time"

	"github.com/example/notehub/config"
	"github.com/example/notehub/db"
)

func main() {
	// 環境変数を読み込む
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("config: %v", err)
	}

	// PostgreSQLへ接続する
	database, err := db.Open(cfg.DatabaseURL)
	if err != nil {
		log.Fatalf("database open: %v", err)
	}
	defer func() {
		if err := db.Close(database); err != nil {
			log.Printf("database close: %v", err)
		}
	}()

	pingCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := db.Ping(pingCtx, database); err != nil {
		log.Fatalf("database ping: %v", err)
	}

	if err := db.Migrate(database); err != nil {
		log.Fatalf("database migrate: %v", err)
	}

	log.Println("NoteHub backend initialization completed")
}
