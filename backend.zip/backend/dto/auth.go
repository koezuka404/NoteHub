package dto

type RegisterRequest struct {
	Name     string `json:"name" validate:"required,min=1,max=10"`
	Email    string `json:"email" validate:"required,email,max=20"`
	Password string `json:"password" validate:"required,min=8,max=15"`
}

type LoginRequest struct {
	Email    string `json:"email" validate:"required,email,max=20"`
	Password string `json:"password" validate:"required,min=8,max=15"`
}

type AuthUserResponse struct {
	ID     string `json:"id"`
	Name   string `json:"name"`
	Email  string `json:"email"`
	Status string `json:"status"`
}

type RegisterResponse struct {
	User      AuthUserResponse `json:"user"`
	CreatedAt string           `json:"createdAt"`
}

type LoginResponse struct {
	User        AuthUserResponse `json:"user"`
	AccessToken string           `json:"accessToken"`
	TokenType   string           `json:"tokenType"`
	ExpiresAt   string           `json:"expiresAt"`
}
