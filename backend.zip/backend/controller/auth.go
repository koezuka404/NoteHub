package controller

import (
	"errors"
	"net/http"

	"github.com/koezuka404/notehub/dto"
	"github.com/koezuka404/notehub/usecase"
	"github.com/labstack/echo/v4"
)

type AuthController struct {
	auth usecase.AuthInputPort
}

func NewAuthController(auth usecase.AuthInputPort) *AuthController {
	return &AuthController{auth: auth}
}

func (c *AuthController) Register(ctx echo.Context) error {
	var request dto.RegisterRequest
	if err := ctx.Bind(&request); err != nil {
		return writeAuthError(ctx, http.StatusBadRequest, "INVALID_REQUEST", "リクエスト形式が不正です")
	}

	output, err := c.auth.Register(ctx.Request().Context(), usecase.RegisterInput{
		Name:     request.Name,
		Email:    request.Email,
		Password: request.Password,
	})
	if err != nil {
		return handleAuthUseCaseError(ctx, err)
	}

	return ctx.JSON(http.StatusCreated, dto.Response{Data: dto.RegisterResponse{
		User: dto.AuthUserResponse{
			ID:     output.ID.String(),
			Name:   output.Name,
			Email:  output.Email,
			Status: string(output.Status),
		},
		CreatedAt: output.CreatedAt,
	}})
}

func (c *AuthController) Login(ctx echo.Context) error {
	var request dto.LoginRequest
	if err := ctx.Bind(&request); err != nil {
		return writeAuthError(ctx, http.StatusBadRequest, "INVALID_REQUEST", "リクエスト形式が不正です")
	}

	output, err := c.auth.Login(ctx.Request().Context(), usecase.LoginInput{
		Email:    request.Email,
		Password: request.Password,
	})
	if err != nil {
		return handleAuthUseCaseError(ctx, err)
	}

	return ctx.JSON(http.StatusOK, dto.Response{Data: dto.LoginResponse{
		User: dto.AuthUserResponse{
			ID:     output.User.ID.String(),
			Name:   output.User.Name,
			Email:  output.User.Email,
			Status: string(output.User.Status),
		},
		AccessToken: output.AccessToken,
		TokenType:   output.TokenType,
		ExpiresAt:   output.ExpiresAt,
	}})
}

func handleAuthUseCaseError(ctx echo.Context, err error) error {
	switch {
	case errors.Is(err, usecase.ErrValidation):
		return writeAuthError(ctx, http.StatusBadRequest, "VALIDATION_ERROR", "入力値が不正です")
	case errors.Is(err, usecase.ErrEmailAlreadyExists):
		return writeAuthError(ctx, http.StatusConflict, "EMAIL_ALREADY_EXISTS", "このメールアドレスは既に登録されています")
	case errors.Is(err, usecase.ErrInvalidCredentials):
		return writeAuthError(ctx, http.StatusUnauthorized, "INVALID_CREDENTIALS", "メールアドレスまたはパスワードが正しくありません")
	case errors.Is(err, usecase.ErrAccountSuspended):
		return writeAuthError(ctx, http.StatusLocked, "ACCOUNT_SUSPENDED", "このアカウントは停止されています")
	case errors.Is(err, usecase.ErrAccountDeleted):
		return writeAuthError(ctx, http.StatusLocked, "ACCOUNT_DELETED", "このアカウントは利用できません")
	default:
		return writeAuthError(ctx, http.StatusInternalServerError, "INTERNAL_ERROR", "内部エラーが発生しました")
	}
}

func writeAuthError(ctx echo.Context, status int, code, message string) error {
	return ctx.JSON(status, dto.ErrorResponse{Error: dto.ErrorBody{Code: code, Message: message}})
}
