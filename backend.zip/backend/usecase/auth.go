package usecase

import (
	"context"
	"time"

	"github.com/google/uuid"
	"github.com/koezuka404/notehub/entity"
)

type UserRepository interface {
	Create(ctx context.Context, user *entity.User) error
	FindByEmail(ctx context.Context, email string) (user *entity.User, found bool, err error)
	ExistsByEmail(ctx context.Context, email string) (bool, error)
}

type PasswordService interface {
	Hash(password string) (string, error)
	Compare(passwordHash, password string) error
}

type AccessTokenService interface {
	GenerateAccessToken(
		userID uuid.UUID,
		authVersion uint,
		now time.Time,
	) (token string, expiresAt time.Time, err error)
}
type AuthInputPort interface {
	Register(ctx context.Context, input RegisterInput) (*RegisterOutput, error)
	Login(ctx context.Context, input LoginInput) (*LoginOutput, error)
}

type AuthUseCase struct {
	users     UserRepository
	passwords PasswordService
	tokens    AccessTokenService
	now       func() time.Time
}

func NewAuthUseCase(
	users UserRepository,
	passwords PasswordService,
	tokens AccessTokenService,
) *AuthUseCase {
	return &AuthUseCase{
		users:     users,
		passwords: passwords,
		tokens:    tokens,
		now:       time.Now,
	}
}
