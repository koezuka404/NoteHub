package usecase

import (
	"context"
	"fmt"

	"github.com/google/uuid"
	"github.com/koezuka404/notehub/entity"
)

// dummyPasswordHash prevents timing attacks when the user does not exist.
const dummyPasswordHash = "$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro4llC/.og/at2.uheWG/igi"

type LoginInput struct {
	Email, Password, IPAddress, UserAgent string
}

type LoginUserOutput struct {
	ID          uuid.UUID
	Name, Email string
	Status      entity.UserStatus
}

type LoginOutput struct {
	User         LoginUserOutput
	AccessToken  string
	RefreshToken string
	CSRFToken    string
	TokenType    string
	ExpiresAt    string
}

func (uc *AuthUseCase) Login(ctx context.Context, input LoginInput) (*LoginOutput, error) {
	if !validateLoginInput(input) {
		return nil, ErrValidation
	}

	email := normalizeEmail(input.Email)
	if uc.loginFailures != nil {
		locked, _, err := uc.loginFailures.IsLocked(ctx, email)
		if err != nil {
			return nil, fmt.Errorf("%w: check login lock: %v", ErrAuthServiceUnavailable, err)
		}
		if locked {
			return nil, ErrLoginTemporarilyLocked
		}
	}

	user, found, err := uc.users.FindByEmail(ctx, email)
	if err != nil {
		return nil, fmt.Errorf("find user by email: %w", err)
	}
	if !found {
		_ = uc.passwords.Compare(dummyPasswordHash, input.Password)
		return nil, uc.recordLoginFailure(ctx, email)
	}
	if !user.CanAuthenticate() {
		return nil, uc.recordLoginFailure(ctx, email)
	}
	if err := uc.passwords.Compare(user.PasswordHash, input.Password); err != nil {
		return nil, uc.recordLoginFailure(ctx, email)
	}
	if uc.loginFailures != nil {
		if err := uc.loginFailures.Reset(ctx, email); err != nil {
			return nil, fmt.Errorf("%w: reset login failures: %v", ErrAuthServiceUnavailable, err)
		}
	}

	now := uc.now().UTC()
	accessToken, expiresAt, err := uc.accessTokens.GenerateAccessToken(user.ID, user.AuthVersion, now)
	if err != nil {
		return nil, fmt.Errorf("generate access token: %w", err)
	}
	rawRefresh, err := uc.randomTokens.GenerateRefreshToken()
	if err != nil {
		return nil, fmt.Errorf("generate refresh token: %w", err)
	}
	refresh, err := entity.NewRefreshToken(user.ID, uc.tokenHashes.Hash(rawRefresh), uuid.New(), now.Add(uc.refreshTokenTTL), now)
	if err != nil {
		return nil, fmt.Errorf("create refresh token entity: %w", err)
	}
	refresh.IPAddress = input.IPAddress
	refresh.UserAgent = input.UserAgent
	if err := uc.refreshTokens.Create(ctx, &refresh); err != nil {
		return nil, fmt.Errorf("save refresh token: %w", err)
	}
	csrfToken, err := uc.randomTokens.GenerateCSRFToken()
	if err != nil {
		return nil, fmt.Errorf("generate csrf token: %w", err)
	}

	return &LoginOutput{
		User:        LoginUserOutput{ID: user.ID, Name: user.Name, Email: user.Email, Status: user.Status},
		AccessToken: accessToken, RefreshToken: rawRefresh, CSRFToken: csrfToken, TokenType: "Bearer", ExpiresAt: expiresAt.Format(timeFormat),
	}, nil
}

func (uc *AuthUseCase) recordLoginFailure(ctx context.Context, email string) error {
	if uc.loginFailures == nil {
		return ErrInvalidCredentials
	}
	locked, _, err := uc.loginFailures.RecordFailure(ctx, email)
	if err != nil {
		return fmt.Errorf("%w: record login failure: %v", ErrAuthServiceUnavailable, err)
	}
	if locked {
		return ErrLoginTemporarilyLocked
	}
	return ErrInvalidCredentials
}
