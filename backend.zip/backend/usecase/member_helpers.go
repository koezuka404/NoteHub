package usecase

import (
	"net/mail"

	"github.com/koezuka404/notehub/entity"
)

const deletedUserDisplayName = "削除済みユーザー"

func normalizeSearchEmail(email string) (string, error) {
	email = normalizeEmail(email)
	if email == "" || len(email) > 255 {
		return "", ErrValidation
	}
	address, err := mail.ParseAddress(email)
	if err != nil || address.Address != email {
		return "", ErrValidation
	}
	return email, nil
}

func memberListUserFields(user *entity.User) (name, email, status string) {
	if user.IsDeleted() {
		return deletedUserDisplayName, "", string(entity.UserStatusDeleted)
	}
	return user.Name, user.Email, string(user.Status)
}

func isAddableMemberUser(user *entity.User) bool {
	return user.CanAuthenticate()
}
