package usecase

import (
	"net/mail"
	"strings"
	"unicode/utf8"
)

const (
	timeFormat        = "2006-01-02T15:04:05Z07:00"
	minNameLength     = 1
	maxNameLength     = 10
	maxEmailLength    = 20
	minPasswordLength = 8
	maxPasswordLength = 15
)

func normalizeEmail(email string) string {
	return strings.ToLower(strings.TrimSpace(email))
}

func validateRegisterInput(input RegisterInput) bool {
	name := strings.TrimSpace(input.Name)
	email := normalizeEmail(input.Email)

	nameLength := utf8.RuneCountInString(name)

	if nameLength < minNameLength || nameLength > maxNameLength {
		return false
	}

	if len(email) == 0 || len(email) > maxEmailLength {
		return false
	}

	if _, err := mail.ParseAddress(email); err != nil {
		return false
	}

	passwordLength := len(input.Password)

	return passwordLength >= minPasswordLength &&
		passwordLength <= maxPasswordLength
}

func validateLoginInput(input LoginInput) bool {
	email := normalizeEmail(input.Email)

	if len(email) == 0 || len(email) > maxEmailLength {
		return false
	}

	if _, err := mail.ParseAddress(email); err != nil {
		return false
	}

	passwordLength := len(input.Password)

	return passwordLength >= minPasswordLength &&
		passwordLength <= maxPasswordLength
}
