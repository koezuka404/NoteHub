package router

import (
	"github.com/koezuka404/notehub/controller"
	"github.com/labstack/echo/v4"
)

func registerAuthRoutes(group *echo.Group, auth *controller.AuthController) {
	group.POST("/auth/register", auth.Register)
	group.POST("/auth/login", auth.Login)
}
